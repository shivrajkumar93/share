package MasterPackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Master {
	public static WebDriver driver;
	
	 
	public static void initialize(){
		System.setProperty("webdriver.chrome.driver","E:\\New folder\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to(" https://opensource-demo.orangehrmlive.com/index.php/");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		

	}
	public WebElement FindElement(String element){
		WebElement ele;
		return ele=driver.findElement(By.xpath(element));
	}
	public void Sendkeys(String element, String text){
		
		this.FindElement(element).sendKeys(text);
		
	}
	public void HoverToElement(String element) throws Throwable{
		
		Actions act = new Actions(driver);
		act.moveToElement(this.FindElement(element)).build().perform();
		System.out.println("1");
		Thread.sleep(500);
				
	}
	
	public String getText(String element){
		return driver.findElement(By.xpath(element)).getText();
	}
	public void click(String element){
		driver.findElement(By.xpath(element)).click();
	}
	
	public void dropdown(String element, String selectvalue){
		Select dropdown1=new Select(driver.findElement(By.xpath(element)));
		dropdown1.selectByVisibleText(selectvalue);
		
		}
	public void radiobutton(String element){
		 if(this.FindElement(element).isDisplayed()==true){
			this.FindElement(element).click(); 	 
		 }
		
		 else{
			 System.out.println("element not found");
			 
			 
		 }
		
	}
	//public void java


}
