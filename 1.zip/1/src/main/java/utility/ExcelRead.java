package utility;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead {
	@SuppressWarnings("resource")
	public String Read(String sheetname,int i ,int j) throws Throwable
	{
		String filename = "C:\\Users\\Shivraj\\workspace\\1\\Data\\Orangehrm.xlsx" ;
		FileInputStream excelFile = new FileInputStream(filename);
		XSSFWorkbook workbook = new XSSFWorkbook(excelFile);
       Sheet sh = workbook.getSheet(sheetname);
       String value= sh.getRow(i).getCell(j).getStringCellValue();
       return value;
	}

}
