package pages;

import MasterPackage.Master;

public class DashBoard extends Master{
	public void DashboardValidation() 
	{

		String str = this.getText("//a[@id='menu_admin_viewAdminModule']");
		if (str.contains("Admin")) {
			System.out.println("name validatation" + "name valiation is successfull");
		}
	}
	public void ClickOnPIM() throws Throwable{
		this.HoverToElement("//a[@id='menu_pim_viewPimModule']");
		this.click("//a[@id='menu_pim_addEmployee']");
		
	}

}
