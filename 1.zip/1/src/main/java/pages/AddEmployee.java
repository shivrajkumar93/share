package pages;

import org.openqa.selenium.By;

import MasterPackage.Master;

public class AddEmployee extends Master{
	
	public String addemployee(String Firstname, String Middlename, String Lastname, String EmployeeId, String UserName, String Password, String ConfirmPassword)
	{
		this.Sendkeys("//input[@name='firstName']", Firstname);
		this.Sendkeys("//input[@name='middleName']", Middlename);
		this.Sendkeys("//input[@name='lastName']", Lastname);
		this.Sendkeys("//input[@name='employeeId']", EmployeeId);
		//this.click("//input[@name='photofile']");
		this.radiobutton("//input[@name='chkLogin']");
		this.Sendkeys("//input[@name='user_name']", UserName);
		this.Sendkeys("//input[@name='user_password']", Password);
		this.Sendkeys("//input[@name='re_password']", ConfirmPassword);
		//this.dropdown("//select[@name='status']", Selectvalue);
		this.click("//input[@id='btnSave']");
		String ExpectedResult=this.FindElement("//div[@id='profile-pic']/h1").getText();
		return ExpectedResult;
	}
	public void adddetails(String OtherId,String  LicenseNumber, String Licence_expiry_date, String mariagestatus, String country, String DateofBirth){
		this.click("//input[@id='btnSave']");
		this.Sendkeys("//input[@id='personal_txtOtherID']", OtherId);
		this.Sendkeys("//input[@id='personal_txtLicenNo']",  LicenseNumber);
		driver.findElement(By.xpath("//input[@id='personal_txtLicExpDate']")).clear();
		this.Sendkeys("//input[@id='personal_txtLicExpDate']", Licence_expiry_date);
		this.radiobutton("//input[@id='personal_optGender_1']");
		this.dropdown("//select[@id='personal_cmbMarital']", mariagestatus);
		this.dropdown("//select[@id='personal_cmbNation']", country);
		driver.findElement(By.xpath("//input[@id='personal_DOB']")).clear();
		this.Sendkeys("//input[@id='personal_DOB']", DateofBirth);
		this.click("//input[@id='btnSave']");
	}
	
	/*public void calander_licence_expiry(String Licence_expiry_date){
		
		String element  ="//*[@id='personal_txtLicExpDate']";
		
		this.Sendkeys(element, Licence_expiry_date);
		
	}
	
	public void calender_Date_OF_BIRTH(String date_of_birth){
		String element = "//*[@id='personal_DOB']";
		this.Sendkeys(element, date_of_birth);
		
		
		
		
		
		
		
	}*/
	
	

}
