package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import MasterPackage.Master;

public class LeaveApplication extends Master {

	public void ClickOnPIM() throws Throwable
	{
		this.HoverToElement("//a[@id='menu_leave_viewLeaveModule']");
		this.click("//a[@id='menu_leave_assignLeave']");
	}
	public void Leaveapplication(String Firstname, String selectvalue,String comment,String Leave_start_date,String Leave_end_date)
	{
		WebElement ele = driver.findElement(By.xpath("//input[@id='assignleave_txtEmployee_empName']"));
		this.Sendkeys("//input[@id='assignleave_txtEmployee_empName']", Firstname);
		
		ele.sendKeys(Keys.DOWN, Keys.RETURN);
		
		
		this.dropdown("//select[@id='assignleave_txtLeaveType']", selectvalue);
		driver.findElement(By.xpath("//*[@id='assignleave_txtFromDate']")).clear();
		this.Sendkeys("//*[@id='assignleave_txtFromDate']",  Leave_start_date);
		driver.findElement(By.xpath("//*[@id='assignleave_txtToDate']")).clear();
		this.Sendkeys("//*[@id='assignleave_txtToDate']",  Leave_end_date);
		this.Sendkeys("//textarea[@id='assignleave_txtComment']", comment);
		this.click("//input[@id='assignBtn']");
	}

}
