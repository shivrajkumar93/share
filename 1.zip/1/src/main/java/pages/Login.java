package pages;

import MasterPackage.Master;

public class Login extends Master{
	public void login(String username, String password ){
		
		this.Sendkeys("//input[@id='txtUsername']", username);
		this.Sendkeys("//input[@id='txtPassword']", password);
		this.click("//input[@id='btnLogin']");
		
	}

}
