package orangetest;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import MasterPackage.Master;
import pages.AddEmployee;
import pages.DashBoard;
import pages.LeaveApplication;
import pages.Login;
import utility.ExcelRead;

public class OrangeTest extends Master{
	Login dologin;
	ExcelRead excel;
	DashBoard Dashbord;
	AddEmployee empadd;
	LeaveApplication Leave;
	@Test(priority = 1, enabled = true)
	public void logintest() throws Throwable 
	{
		//initialize();
		dologin = new Login();
		excel = new ExcelRead();
		String username = excel.Read("Sheet1", 1, 0);
		System.out.println(username);
		String password = excel.Read("Sheet1", 1, 1);
		System.out.println(password);
		initialize();
		dologin.login(username, password);
		// After logging error message like(This page isn’t working) so i am navigating it back
		driver.navigate().back();
	}
	@Test(priority=2,enabled=true)
	public void dashbord() throws Throwable
	{
		Dashbord= new DashBoard();
		
		Dashbord.DashboardValidation();
		Dashbord.ClickOnPIM();
		//driver.close();
	}
	@Test(priority=3,enabled=true)
	public void empaddition() throws Throwable
	{
		empadd=new AddEmployee();
		excel=new ExcelRead();
		String Firstname = excel.Read("Sheet1", 1, 2);
		String Middlename=excel.Read("Sheet1", 1, 3);
		String Lastname=excel.Read("Sheet1", 1, 4);
		String EmployeeId=excel.Read("Sheet1", 1, 5);
		String UserName=excel.Read("Sheet1", 1, 6);
		String Password=excel.Read("Sheet1", 1, 7);
		String ConfirmPassword=excel.Read("Sheet1", 1, 8);
		
		
		String Expectedname = empadd.addemployee(Firstname, Middlename, Lastname, EmployeeId, UserName, Password, ConfirmPassword);

		String Actualname= Firstname+" "+Middlename+" "+Lastname;
		Assert.assertEquals(Actualname, Expectedname);
		String OtherId= excel.Read("sheet1", 1, 9);
		String LicenseNumber= excel.Read("sheet1", 1, 10);
		String Licence_expiry_date= excel.Read("sheet1", 1, 11);
		String DateofBirth= excel.Read("sheet1", 1, 12);
		String mariagestatus= excel.Read("sheet1", 1, 13);
		String country=excel.Read("sheet1", 1, 14);
		
		empadd.adddetails(OtherId, LicenseNumber, Licence_expiry_date, mariagestatus, country, DateofBirth);
		
		//empadd.addemployee("Ram", "Mohan", "Sharma", "28", "RamM", "123456789", "123456789", "Enabled");
		
	}

	@Test(priority=4,enabled=true)
	public void leaveapplication() throws Throwable{
		Leave=new LeaveApplication();
	
		excel=new ExcelRead();
		String Firstname1 = excel.Read("Sheet1", 1, 2);
		String Middlename=excel.Read("Sheet1", 1, 3);
		String Lastname=excel.Read("Sheet1", 1, 4);
		String Firstname= Firstname1+" "+Middlename+" "+Lastname;
		String selectvalue = excel.Read("Sheet1", 1, 18);
		System.out.println(selectvalue);
		String comment = excel.Read("Sheet1", 1, 17);
		String Leave_start_date= excel.Read("sheet1", 1, 15);
		String Leave_end_date= excel.Read("sheet1", 1, 16);
	
		Leave.ClickOnPIM();
		Leave.Leaveapplication(Firstname, selectvalue, comment, Leave_start_date, Leave_end_date);
		
	}
	@AfterTest
	public void ClosingBrowser(){
		driver.close();
	}
}
